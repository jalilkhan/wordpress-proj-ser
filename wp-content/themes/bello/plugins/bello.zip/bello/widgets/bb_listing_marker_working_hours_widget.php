
	<ul class="bt_bb_listing_marker_meta_data_items">
		<li class="bt_bb_listing_marker_meta_working_hours"><span>Now closed <small class="bt_bb_listing_marker_meta_opens_at">Opens  at <strong>9AM</strong></small></span></li>
		<li class="bt_bb_listing_marker_meta_working_hours bt_bb_listing_marker_meta_now_working"><span>Now open <span class="bt_bb_listing_marker_meta_show_working_hours">Show working hours</span></span>
			<dl>
				<dt>Monday</dt>
				<dd>9:00 AM - 10:00 PM</dd>
				<dt>Tuesday</dt>
				<dd>9:00 AM - 10:00 PM</dd>
				<dt>Wednesday</dt>
				<dd>9:00 AM - 10:00 PM</dd>
				<dt>Thursday</dt>
				<dd>9:00 AM - 10:00 PM</dd>
				<dt>Friday</dt>
				<dd>9:00 AM - 10:00 PM</dd>
				<dt>Saturday</dt>
				<dd>12:00 AM - 10:00 PM</dd>
				<dt>Sunday</dt>
				<dd class="bt_bb_listing_marker_meta_working_hours_closed">Closed</dd>
			</dl>
		</li>
	</ul>
