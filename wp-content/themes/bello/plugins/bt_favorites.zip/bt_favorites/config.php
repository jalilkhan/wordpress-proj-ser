<?php

define( 'BT_FAVORITES_PLUGIN_FILE', __FILE__ );
define( 'BT_FAVORITES_COOKIE_NAME', 'bt-favorites' );
define( 'BT_FAVORITES_META_NAME', 'bt_favorites' );

global $page_count;
$page_count = 1;
